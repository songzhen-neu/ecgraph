a=[[0,1],[2,3]]
b=a
a[0][0]=5
print(a)
print(b)