import numpy as np
a=np.ones(shape=(3,3))
b=np.zeros(shape=(3,3))

