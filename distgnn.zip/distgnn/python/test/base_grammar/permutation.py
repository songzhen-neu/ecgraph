import numpy as np

random_index=np.random.permutation(100)
print(random_index)
print(random_index.max())
print(random_index.min())
print(random_index.size)