//
// Created by songzhen on 2020/10/5.
//
template<class T>
int length(T& arr){
    return sizeof(arr)/sizeof(arr[0]);
}