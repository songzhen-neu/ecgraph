//
// Created by songzhen on 2020/10/15.
//

#ifndef DGNN_TEST_STRING_SPLIT_H
#define DGNN_TEST_STRING_SPLIT_H

#include <iostream>
#include <vector>
using namespace std;
void split(const std::string& s, std::vector<std::string>& v, const std::string& c);

#endif //DGNN_TEST_STRING_SPLIT_H
