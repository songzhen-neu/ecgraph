//
// Created by songzhen on 2020/9/26.
//
#include <iostream>
#include <stdio.h>
#include "bittest.h"
#include <climits>
void BitClass::print_a_bit(){
    std::cout<<a_bit1<<","<<a_bit2<<std::endl;
    std::cout<<sizeof(int)<<std::endl;
}