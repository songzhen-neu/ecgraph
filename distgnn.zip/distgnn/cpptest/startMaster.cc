//
// Created by songzhen on 2020/12/31.
//

//#include "../core/service/dgnn_client.h"
//#include "../dgnn_server.h"
//int main(){
//    ServiceImpl service;
//    service.RunServerByPy("192.168.184.157:4001");
//
//}