import random
import os
import context.context as context
import time

import sys, os

BASE_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))) + '/data_agl/'

start = time.time()
dataset_name = context.glContext.config['data_path'].split('/')[3]
FilePath = "/mnt/data/" + dataset_name
localPath = BASE_PATH + dataset_name

FilePath_fc = FilePath + "/featsClass.txt"
FilePath_e = FilePath + "/edges.txt"
FilePath_agl_dir = FilePath + "/agl/"
FilePath_agl = "/graphflat"
f = open(FilePath_fc, 'r')
feats = {}
labels = {}
edges = {}

n_sample = 20
n_layer = 2

feat_size = context.glContext.config['feature_dim']
batch_size = context.glContext.config['batch_size']
data_num = context.glContext.config['data_num']
worker_num = context.glContext.config['worker_num']
train_num = context.glContext.config['train_num']
val_num = context.glContext.config['val_num']
test_num = context.glContext.config['test_num']

node_size_workers = []
id = context.glContext.config['id']
train_num_workeri = int((data_num - val_num - test_num) / worker_num)
node_count_workers = []
fws = []
for i in range(worker_num):
    if i == 0:
        node_size_workers.append(train_num_workeri + val_num + test_num)
    else:
        node_size_workers.append(int(train_num_workeri))
    node_count_workers.append(0)
    fws.append(open(localPath + FilePath_agl +str(worker_num)+'-'+str(n_layer)+'-' +str(i) + '.txt', 'w'))

for line in f.readlines():
    line = line.strip()
    id_feat_class = line.split('\t')
    feats[id_feat_class[0]] = id_feat_class[1:len(id_feat_class) - 1]
    labels[id_feat_class[0]] = id_feat_class[len(id_feat_class) - 1]
f.close()

f = open(FilePath_e, 'r')

for line in f.readlines():
    line = line.strip()
    dst_src = line.split('\t')
    if not edges.__contains__(dst_src[0]):
        edges[dst_src[0]] = set()
    edges[dst_src[0]].add(dst_src[1])
    if not edges.__contains__(dst_src[1]):
        edges[dst_src[1]] = set()
    edges[dst_src[1]].add(dst_src[0])
f.close()

edges_sample = {}
# sample and build the k-hop graph
for i in range(len(labels)):
    if not edges.__contains__(str(i)):
        edges[str(i)] = set()
        edges[str(i)].add(str(i))
    edge_for_i = list(edges[str(i)])
    edges_sample[str(i)] = []
    if len(edge_for_i) > n_sample:
        ids = random.sample(range(0, len(edge_for_i)), n_sample)
        for j in range(n_sample):
            edges_sample[str(i)].append(str(ids[j]))
        if not edges_sample[str(i)].__contains__(str(i)):
            edges_sample[str(i)].append(str(i))
    else:
        edges_sample[str(i)] = edge_for_i

vertexs = {}
for i in range(len(labels)):
    ids_neighbor = edges_sample[str(i)].copy()
    vertex = {}
    # vertex['n'+str(0)]=ids_neighbor.copy()
    for k in range(n_layer):
        vertex['n' + str(k)] = ids_neighbor.copy()
        if k < n_layer -1:
            cur_neighbor = ids_neighbor.copy()
            # ids_neighbor.clear()
            for nei in cur_neighbor:
                ids_neighbor.extend(edges_sample[str(nei)])
            ids_neighbor = set(ids_neighbor)
            ids_neighbor = list(ids_neighbor)
    vertexs[str(i)] = vertex

isExists = os.path.exists(FilePath_agl_dir)
if not isExists:
    os.makedirs(FilePath_agl_dir)

# id,label,feature,nei0,nei1,...,adj_k-1_hop,nei_k-2_feat, k(layers)+4(id,label,feat,adj_k-1_hop,nei_k-1_feat) '\t' for each item, ' ' for each value
# 0\t0\t0.0 1.0\t1 2 3\t1 2 3 4 5\tfeat\t1:2,3,4 2:3,4,5 3:1,2

cur_worker = 0

for i in range(len(labels)):
    str_gf = str(i) + '\t' + labels[str(i)] + '\t' + ' '.join(feats[str(i)]) + '\t'
    for k in range(n_layer):
        str_gf += ' '.join(vertexs[str(i)]['n' + str(k)]) + '\t'
    # nei_lastlayer = vertexs[str(i)]['n' + str(n_layer - 1)]
    # for nei in nei_lastlayer:
    #     feat = feats[str(nei)]
    #     if nei == nei_lastlayer[len(nei_lastlayer) - 1]:
    #         str_gf += ' '.join(feat) + '\t'
    #     else:
    #         str_gf += ' '.join(feat) + ' '

    # print(len(str_gf))
    # build the adjs for the second to last layer
    nei_second2lastlayer = vertexs[str(i)]['n' + str(n_layer - 2)]
    str_adj = ''
    for nei in nei_second2lastlayer:
        adj_nei = edges_sample[nei]
        if nei is nei_second2lastlayer[len(nei_second2lastlayer) - 1]:
            str_adj += nei + ':' + ','.join(adj_nei) + '\n'
        else:
            str_adj += nei + ':' + ','.join(adj_nei) + ' '
    str_gf += str_adj

    fws[cur_worker].write(str_gf)
    node_count_workers[cur_worker] += 1
    if node_count_workers[cur_worker] == node_size_workers[cur_worker]:
        cur_worker += 1
        if cur_worker == worker_num:
            break

for i in range(worker_num):
    fws[i].close()

end = time.time()
print("time:{0}".format(end - start))
