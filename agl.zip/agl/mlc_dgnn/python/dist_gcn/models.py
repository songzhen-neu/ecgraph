import torch.nn as nn
import torch.nn.functional as F
from dist_gcn.layers import GraphConvolution
from context import context
import time
from torch.nn import init
import torch
import numpy as np
import util_python.data_trans as dt
import scipy.sparse as sp
import util_python.remote_access as ra


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, autograd):  # 底层节点的参数，feature的个数；隐层节点个数；最终的分类数
        super(GCN, self).__init__()  # super()._init_()在利用父类里的对象构造函数
        torch.manual_seed(1)
        nhid_len = len(nhid)
        self.gc = []
        for i in range(1, nhid_len+2):
            if i == 1:
                self.gc.append(GraphConvolution(nfeat, nhid[0], 0))
            elif i!=nhid_len+1:
                self.gc.append(GraphConvolution(nhid[i-2], nhid[i-1], i-1))
            elif i == nhid_len+1:
                self.gc.append(GraphConvolution(nhid[i-2], nclass, i-1))


        self.dropout = dropout
        self.autograd = autograd

    # 输入分别是特征和邻接矩阵。最后输出为输出层做log_softmax变换的结果
    def forward(self, adjs_old, nodes_for_each_layer, feat_map, nodeid_map,nodeid_new2old_map):
        layer_num=len(self.gc)
        x=[feat_map[nodeid_new2old_map[i]] for i in range(len(nodeid_map))]
        x=torch.FloatTensor(x)
        for i in range(layer_num):
            nodes_fori=nodes_for_each_layer[layer_num-i]
            nodes_fori_r1=nodes_for_each_layer[layer_num-i-1]
            adj_newid={}
            for id in nodes_fori_r1:
                adj_newid[nodeid_map[id]]=[nodeid_map[adjs_old[id][x]] for x in range(len(adjs_old[id]))]
            edges = []
            # 从adj中解析出edge
            for j in range(len(adj_newid)):
                # if not adj_newid.__contains__(j):
                #     print(str(j)+','+str(len(adj_newid)))
                for nei_id in adj_newid[j]:
                    edges.append([j, nei_id])
            edges = np.array(edges)
            adjs = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                                 shape=(len(nodes_fori), len(nodes_fori)),
                                 dtype=np.int)
            adjs = adjs + adjs.T.multiply(adjs.T > adjs) - adjs.multiply(adjs.T > adjs)
            adjs = dt.normalize_gcn(adjs + sp.eye(adjs.shape[0]))  # eye创建单位矩阵，第一个参数为行数，第二个为列数
            adjs = adjs[range(len(nodes_fori_r1))]
            adjs = dt.sparse_mx_to_torch_sparse_tensor(adjs)  # 邻接矩阵转为tensor处理
            x=self.gc[i](x,adjs)
            if i != len(self.gc)-1:
                x=F.relu(x)
        return F.log_softmax(x, dim=1)
