a=[[1,2],[3,4],[1,2],[3,4],[1,2],[3,4]]
b=[[5,2],[5,4]]

a.extend(b)

# from 0 catch 4 items
c=a[0:4]

print(a)