str1='000000000000aaa000'
str2='           aaaa          '
# delete '0's in head and tail
str1=str1.strip('0')
# delete ' 's in head and tail
str2=str2.strip()

print(str1)
print(str2)
