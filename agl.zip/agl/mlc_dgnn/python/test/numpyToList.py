import numpy as np

a=[[1,2],[2,3]]

b=np.array(a)
print(type(b))

c=b.tolist()

print(type(c))