global hLast
global hMom
global mv1
global mv2

global hijlast

hLast= {}
hMom={}
mv1={}
mv2={}
