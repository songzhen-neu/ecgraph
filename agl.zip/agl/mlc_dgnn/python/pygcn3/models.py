import torch.nn as nn
import torch.nn.functional as F
from pygcn3.layers import GraphConvolution
import torch
import numpy as np
import scipy.sparse as sp
import util_python.data_trans as dt


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):  # 底层节点的参数，feature的个数；隐层节点个数；最终的分类数
        super(GCN, self).__init__()  #  super()._init_()在利用父类里的对象构造函数

        self.gc1 = GraphConvolution(nfeat, nhid,0)   # gc1输入尺寸nfeat，输出尺寸nhid
        self.gc2 = GraphConvolution(nhid, nhid,1)  # gc2输入尺寸nhid，输出尺寸nclass
        self.gc3 = GraphConvolution(nhid, nclass,2)  # gc2输入尺寸nhid，输出尺寸nclass
        self.dropout = dropout

    # 输入分别是特征和邻接矩阵。最后输出为输出层做log_softmax变换的结果
    def forward(self, adjs_old, nodes_for_each_layer, feat_map, nodeid_map, nodeid_new2old_map):
        x=[feat_map[nodeid_new2old_map[i]] for i in range(len(nodeid_map))]
        x=torch.FloatTensor(x)

        nodes_fori=nodes_for_each_layer[3]
        nodes_fori_r1=nodes_for_each_layer[2]
        adj_newid={}
        for id in nodes_fori_r1:
            adj_newid[nodeid_map[id]]=[nodeid_map[adjs_old[id][x]] for x in range(len(adjs_old[id]))]
        edges = []
        # 从adj中解析出edge
        for key in adj_newid.keys():
            # if not adj_newid.__contains__(j):
            #     print(str(j)+','+str(len(adj_newid)))
            for nei_id in adj_newid[key]:
                edges.append([key, nei_id])
        edges = np.array(edges)
        adjs = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                             shape=(len(nodes_fori), len(nodes_fori)),
                             dtype=np.int)
        adjs = adjs + adjs.T.multiply(adjs.T > adjs) - adjs.multiply(adjs.T > adjs)
        adjs = dt.normalize_gcn(adjs + sp.eye(adjs.shape[0]))  # eye创建单位矩阵，第一个参数为行数，第二个为列数
        adjs = adjs[range(len(nodes_fori_r1))]
        adjs = dt.sparse_mx_to_torch_sparse_tensor(adjs)  # 邻接矩阵转为tensor处理

        x = F.relu(self.gc1(x, adjs))    # adj即公式Z=softmax(A~Relu(A~XW(0))W(1))中的A~
        # x = F.dropout(x, self.dropout, training=self.training)  # x要dropout

        nodes_fori=nodes_for_each_layer[2]
        nodes_fori_r1=nodes_for_each_layer[1]
        adj_newid={}
        for id in nodes_fori_r1:
            # if not adjs_old.__contains__(id):
            #     print(id)
            adj_newid[nodeid_map[id]]=[nodeid_map[adjs_old[id][x]] for x in range(len(adjs_old[id]))]
        edges = []
        # 从adj中解析出edge
        for j in adj_newid.keys():
            # if not adj_newid.__contains__(j):
            #     print(str(j)+','+str(len(adj_newid)))
            for nei_id in adj_newid[j]:
                edges.append([j, nei_id])
        edges = np.array(edges)
        adjs2 = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                             shape=(len(nodes_fori), len(nodes_fori)),
                             dtype=np.int)
        adjs2 = adjs2 + adjs2.T.multiply(adjs2.T > adjs2) - adjs2.multiply(adjs2.T > adjs2)
        adjs2 = dt.normalize_gcn(adjs2 + sp.eye(adjs2.shape[0]))  # eye创建单位矩阵，第一个参数为行数，第二个为列数
        adjs2 = adjs2[range(len(nodes_fori_r1))]
        adjs2 = dt.sparse_mx_to_torch_sparse_tensor(adjs2)  # 邻接矩阵转为tensor处理
        x = F.relu(self.gc2(x, adjs2))



        nodes_fori=nodes_for_each_layer[1]
        nodes_fori_r1=nodes_for_each_layer[0]
        adj_newid={}
        for id in nodes_fori_r1:
            # if not adjs_old.__contains__(id):
            #     print(id)
            adj_newid[nodeid_map[id]]=[nodeid_map[adjs_old[id][x]] for x in range(len(adjs_old[id]))]
        edges = []
        # 从adj中解析出edge
        for j in adj_newid.keys():
            # if not adj_newid.__contains__(j):
            #     print(str(j)+','+str(len(adj_newid)))
            for nei_id in adj_newid[j]:
                edges.append([j, nei_id])
        edges = np.array(edges)
        adjs3 = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                              shape=(len(nodes_fori), len(nodes_fori)),
                              dtype=np.int)
        adjs3 = adjs3 + adjs3.T.multiply(adjs3.T > adjs3) - adjs3.multiply(adjs3.T > adjs3)
        adjs3 = dt.normalize_gcn(adjs3 + sp.eye(adjs3.shape[0]))  # eye创建单位矩阵，第一个参数为行数，第二个为列数
        adjs3 = adjs3[range(len(nodes_fori_r1))]
        adjs3 = dt.sparse_mx_to_torch_sparse_tensor(adjs3)  # 邻接矩阵转为tensor处理
        x = self.gc3(x, adjs3)

        return F.log_softmax(x, dim=1)