from __future__ import division
from __future__ import print_function

import sys, os

BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

sys.path.insert(0, BASE_PATH)
sys.path.insert(1, BASE_PATH + '/../')
# sys.path.insert(2, BASE_PATH + '/../../')
print(BASE_PATH)
import time
import numpy as np
from sklearn.metrics import f1_score
import util_python.param_parser as pp
import util_python.metric as metric
from sklearn.metrics import accuracy_score
# BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(os.path.dirname(os.path.abspath(__file__)))
# sys.path.insert(0, BASE_PATH)
# # sys.path.insert(1, BASE_PATH + '/../')
import ecgraph
import torch.nn.functional as F
import scipy.sparse as sp
import context.store as store
import util_python.param_util as pu

# example2=ctypes.CDLL('../../cmake/build/example2.cpython-36m-x86_64-linux-gnu.so')

from cmake.build.example2 import *
from context import context

from dist_gcn.models import GCN
# import autograd.autograd as atg
import autograd.autograd_new as autoG
from util_python import data_trans as dt
import torch as torch

from multiprocessing import cpu_count
import torch.optim as optim

cpu_num = cpu_count()  # 自动获取最大核心数目
print("cpu num:{0}".format(cpu_num))
os.environ['OMP_NUM_THREADS'] = str(cpu_num)
os.environ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
os.environ['MKL_NUM_THREADS'] = str(cpu_num)
os.environ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
os.environ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
torch.set_num_threads(cpu_num)

from pygcn2.utils import load_data, accuracy
from pygcn2.models import GCN


def val_and_test(model, f, layer_num, feat_size, feat_map, epoch_time, epoch):
    model.eval()

    adjs, nodes_for_each_layer, labels, nodeid_map, nodeid_new2old_map = buildSubGraph(f, layer_num,
                                                                                       feat_size,
                                                                                       context.glContext.config[
                                                                                           'val_num'])
    labels = torch.LongTensor(labels)
    # begin training
    pred = model(adjs, nodes_for_each_layer, feat_map, nodeid_map, nodeid_new2old_map)
    val_acc = accuracy_score(labels.detach().numpy(),
                             pred.detach().numpy().argmax(axis=1))

    model.eval()
    adjs, nodes_for_each_layer, labels, nodeid_map, nodeid_new2old_map = buildSubGraph(f, layer_num,
                                                                                       feat_size,
                                                                                       context.glContext.config[
                                                                                           'test_num'])
    labels = torch.LongTensor(labels)
    # begin training
    pred = model(adjs, nodes_for_each_layer, feat_map, nodeid_map, nodeid_new2old_map)
    test_acc = accuracy_score(labels.detach().numpy(),
                              pred.detach().numpy().argmax(axis=1))

    print('epoch:{0:04d}, val_acc:{1:.4f}, test_acc:{2:.4f}, time:{3:.4f}'.format(epoch, val_acc, test_acc, epoch_time))


def train(model):
    # f = open('/home/songzhen/workspace/mlc_dgnn/data_agl/' + context.glContext.config['data_path'].split('/')[
    #     -1] + '/graphflat'+str(context.glContext.config['id'])+'.txt')
    # optimizer = optim.Adam(model.parameters(),
    #                        lr=context.glContext.config['lr'], weight_decay=5e-4)
    optimizer = optim.Adam(model.parameters(), lr=context.glContext.config['lr'], weight_decay=5e-4)

    worker_num = context.glContext.config['worker_num']
    layer_num = context.glContext.config['layerNum']
    f = open('/mnt/data/' + context.glContext.config['data_path'].split('/')[
        -1] + '/agl/graphflat' + str(worker_num) + '-' + str(layer_num) + '-' + str(
        context.glContext.config['id']) + '.txt')

    feat_size = context.glContext.config['feature_dim']
    batch_size = context.glContext.config['batch_size']
    data_num = context.glContext.config['data_num']
    train_num = context.glContext.config['train_num']
    val_num = context.glContext.config['val_num']
    test_num = context.glContext.config['test_num']
    hidden=context.glContext.config['hidden']
    class_num=context.glContext.config['class_num']


    feat_map = buildCompleteFeature()
    id = context.glContext.config['id']
    train_num_workeri = (train_num) / worker_num
    if id == 0:
        data_num = int(train_num_workeri) + val_num + test_num
    else:
        data_num = int(train_num_workeri / worker_num)

    for epoch in range(context.glContext.config['iterNum']):
        f.seek(0)
        epoch_time = 0
        for i in range(int(train_num_workeri / context.glContext.config['batch_size'])):
            optimizer.zero_grad()
            model.train()
            adjs, nodes_for_each_layer, labels, nodeid_map, nodeid_new2old_map = buildSubGraph(f, layer_num,
                                                                                               feat_size,
                                                                                               batch_size)
            start = time.time()
            labels = torch.LongTensor(labels)
            # begin training
            pred = model(adjs, nodes_for_each_layer, feat_map, nodeid_map, nodeid_new2old_map)
            loss = F.nll_loss(pred, labels)
            # print(loss)
            # print(accuracy_score(labels.detach().numpy(),
            #                      pred.detach().numpy().argmax(axis=1)))

            loss.backward()
            # optimizer.step()
            # begin updating parameters
            laynum = context.glContext.config["layerNum"]

            context.glContext.gradients['w' + str(0)] = model.gc1.weight.grad.detach().flatten().numpy().tolist()
            context.glContext.gradients['b' + str(0)] = model.gc1.bias.grad.detach().flatten().numpy().tolist()
            context.glContext.gradients['w' + str(1)] = model.gc2.weight.grad.detach().flatten().numpy().tolist()
            context.glContext.gradients['b' + str(1)] = model.gc2.bias.grad.detach().flatten().numpy().tolist()

            # optimizer.step()
            server_num = context.glContext.config['server_num']
            agg_grad = {}
            for key in context.glContext.gradients:
                num_g = int(len(context.glContext.gradients[key]) / server_num)
                agg_grad[key] = []
                for sid in range(server_num):
                    if sid == server_num - 1:
                        agg_grad[key].extend(
                            context.glContext.dgnnServerRouter[sid].server_aggGrad(context.glContext.config['id'], sid,
                                                                                   context.glContext.config['lr'],
                                                                                   key,
                                                                                   context.glContext.gradients[key][
                                                                                   sid * num_g:]))

                    else:
                        agg_grad[key].extend(
                            context.glContext.dgnnServerRouter[sid].server_aggGrad(context.glContext.config['id'], sid,
                                                                                   context.glContext.config['lr'],
                                                                                   key,
                                                                                   context.glContext.gradients[key][
                                                                                   sid * num_g:(sid + 1) * num_g]))



            model.gc1.weight.grad.data=torch.FloatTensor(agg_grad['w' + str(0)]).reshape(feat_size,hidden[0])
            model.gc1.bias.grad.data=torch.FloatTensor(agg_grad['b' + str(0)]).reshape(hidden[0])
            model.gc2.weight.grad.data=torch.FloatTensor(agg_grad['w' + str(1)]).reshape(hidden[0],class_num)
            model.gc2.bias.grad.data=torch.FloatTensor(agg_grad['b' + str(1)]).reshape(class_num)
            optimizer.step()


            end = time.time()
            epoch_time += (end - start)
        if id == 0:
            val_and_test(model, f, layer_num, feat_size, feat_map, epoch_time, epoch)
        context.glContext.dgnnServerRouter[0].server_Barrier(0)


# 定义测试函数，相当于对已有的模型在测试集上运行对应的loss与accuracy
def test(model, idx_test, adj, features, labels):
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))


def buildSubGraph(f, layer_num, feat_size, read_size):
    batch = []
    adjs = {}
    train_nodes = []
    nodes_for_each_layer = {x: [] for x in range(layer_num + 1)}
    labels = []
    feats = {}
    nodeid_map = {}
    nodeid_new2old_map = {}
    # begin building subgraph for a batch
    for j in range(read_size):
        batch.append(f.readline().strip())
    for v in batch:
        # parse the vertex
        v_split = v.split('\t')
        vid = int(v_split[0])
        train_nodes.append(vid)
        lab = int(v_split[1])
        labels.append(int(lab))
        feat = v_split[2].split(' ')
        feat = [float(feat[x]) for x in range(len(feat))]
        feats[vid] = feat
        nodes_for_each_layer[0].append(vid)

        nei = {}

        adj_for_vid = None
        for l in range(layer_num):
            nei[l] = v_split[3 + l].split(' ')
            nei[l] = [int(nei[l][x]) for x in range(len(nei[l]))]
            if l==0:
                adj_for_vid= nei[l].copy()
            nodes_for_each_layer[l + 1].extend(nei[l])

        adj_tmp = v_split[3 + layer_num].split(' ')


        for adj_v in adj_tmp:
            id = int(adj_v.split(':')[0])
            nei_forid = adj_v.split(':')[1].split(',')
            nei_forid = [int(nei_forid[x]) for x in range(len(nei_forid))]
            adjs[id] = nei_forid
        adjs[vid] = adj_for_vid
    # remove the duplicate
    for x in range(len(nodes_for_each_layer)):
        if x!=len(nodes_for_each_layer)-1:
            nodes_for_each_layer[x+1].extend(nodes_for_each_layer[x])
        nodes_for_each_layer[x] = sorted(list(set(nodes_for_each_layer[x])))

    # re-encode the vertex as a consecutive ids
    count = 0
    for l in range(len(nodes_for_each_layer)):
        for v in nodes_for_each_layer[l]:
            if not nodeid_map.__contains__(v):
                nodeid_map[v] = count
                nodeid_new2old_map[count] = v
                count += 1
    for id in nodes_for_each_layer[0]:
        for nei in adjs[id]:
            if not nodes_for_each_layer[1].__contains__(nei):
                print(str(id)+','+str(nei))
    return adjs, nodes_for_each_layer, labels, nodeid_map, nodeid_new2old_map


def buildCompleteFeature():
    featMap = {}
    feat_size = context.glContext.config['feature_dim']
    with open(context.glContext.config['data_path'] + '/featsClass.txt') as f:
        for line in f.readlines():
            line = line.strip()
            id_feat_class = line.split('\t')
            id = int(id_feat_class[0])
            featMap[id] = id_feat_class[1:len(id_feat_class) - 1]
            featMap[id] = [float(featMap[id][i]) for i in range(feat_size)]
    return featMap


def distgnn():
    pp.parserInit()
    pp.printContext()

    if context.glContext.config['role'] == 'server':
        context.glContext.worker_id = context.glContext.config['id']
        ServiceImpl.RunServerByPy(context.glContext.config['server_address'][context.glContext.config['id']],
                                  context.glContext.worker_id)

    elif context.glContext.config['role'] == 'worker':
        # adj, features, labels, idx_train, idx_val, idx_test = load_data()
        # Model and optimizer
        model = GCN(nfeat=context.glContext.config['feature_dim'],
                    nhid=context.glContext.config['hidden'][0],
                    nclass=context.glContext.config['class_num'],
                    dropout=0.5)
        context.glContext.initCluster()
        pu.assignParam()
        context.glContext.dgnnClient.initCompressBitMap(context.glContext.config['bitNum'])
        context.glContext.dgnnServerRouter[0].server_Barrier(0)
        t_total = time.time()

        train(model)
        print("Optimization Finished!")
        print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
    elif context.glContext.config['role'] == 'master':
        context.glContext.worker_id = context.glContext.config['id']
        ServiceImpl.RunServerByPy(context.glContext.config['master_address'], 0)

    # Train model  逐个epoch进行train，最后test


if __name__ == "__main__":
    distgnn()
