# package
# __init__.py
from ecgraph.BackWard import *
from ecgraph.ECTensor import *
from ecgraph.Function import *
