//
// Created by songzhen on 2020/9/26.
//

#ifndef DGNN_TEST_BITTEST_H
#define DGNN_TEST_BITTEST_H
class BitClass{
public:
    unsigned int a_bit1:1;
    unsigned int a_bit2:2;
    void print_a_bit();
};
#endif //DGNN_TEST_BITTEST_H
